import time
starttime=time.time()
A=input('enter a:')
B=input('enter b:')
a=int(A)
b=int(B)
C=input('enter c:')
c=int(C)
if(a>b and a>c):
    print("LARGEST NUM IS:",a)

elif(b>c and b>a):
    print("LARGEST NUM IS:",b)

elif(c>a and c>b):
    print("LARGEST NUM IS:",c)

endtime=time.time()
tt=(endtime-starttime)
print('TOTAL TIME OF EXECUTION:',tt)
