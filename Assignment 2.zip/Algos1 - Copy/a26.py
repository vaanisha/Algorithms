import time
starttime=time.time()
A=input('enter a:')
B=input('enter b:')
a=int(A)
b=int(B)
if(a<b):
    print("SMALLEST NUM IS:",a)
else:
    print("SMALLEST NUM IS:",b)
endtime=time.time()
tt=(endtime-starttime)
print('TOTAL TIME OF EXECUTION:',tt)
