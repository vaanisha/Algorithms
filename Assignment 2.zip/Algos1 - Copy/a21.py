import time
starttime=time.time()
A=input('enter a:')
B=input('enter b:')
a=int(A)
b=int(B)
def sum(a,b):
    z=a+b
    print("SUM OF GIVEN NUMBERS IS:",z)
sum(a,b)
endtime=time.time()
tt=(endtime-starttime)
print('TOTAL TIME OF EXECUTION:',tt)
