import time
starttime=time.time()
a=input('enter a:')
b=input('enter b:')
t=a
a=b
b=t
print("AFTERING SWAPING:",a,b)
endtime=time.time()
tt=(endtime-starttime)
print('TOTAL TIME OF EXECUTION:',tt)
