def Partition(a, l, h) :
    x = l
    pivot = a[x]
    p = l
    q = h
    while p < q :
        while p <= h and a[p] >= pivot :
            p = p + 1

        while q >= p and q > l and a[q] <= pivot :
            q = q - 1
        if p < q :
            a[p], a[q] = a[q], a[p]

    a[x], a[q] = a[q], a[x]
    return q


def Quicksort(a, l, h) :
    if l < h :
        m = Partition(a, l, h)
        Quicksort(a, l, m - 1)
        Quicksort(a, m + 1, h)


r = input("Enter an array").split()
for i in range(len(r)) :
    r[i] = int(r[i])
Quicksort(r, 0, len(r) - 1)
print(r)
