import numpy as np #TO GET THE ATTRIBUTES OF AN IMAGE
import matplotlib.pyplot as plt #TO SHOW/DISPLAY THE IMAGE AND READ THE IMAGE
import os  #TO READ FOLDERS IN OUR SYSTEM

def Partition(a, l, h) :
    x=l
    pivot = a[x]
    p = l  #STARTING INDEX OF GIVEN ARRAY
    q = h  #ENDING INDEX OF GIVEN ARRAY
    while p < q :
        while p <= h and a[p] <= pivot :
            p = p + 1

        while q >= p and q > l and a[q] >= pivot :
            q = q - 1
        if p < q :
            a[p], a[q] = a[q], a[p]  #EXCHANGING A[p] WITH A[q]

    a[x],a[q]=a[q],a[x] #EXCHANGING PIVOT WITH A[q]
    return q  #RETURNING THE INDEX FOR PARTITIONING


def Quicksort(a, l, h) :
    if l<h:
        m = Partition(a, l, h)
        Quicksort(a, l, m - 1)  #PERFORMING QUICK SORT ON THE FIRST ARRAY
        Quicksort(a, m + 1, h)  #PERFORMING QUICK SORT ON THE SECOND ARRAY

images=[]
dir = input("Enter the path of the folder :")
with os.scandir('dir') as entries:
    for i in entries:
        images.append(i.name)#ENTRIES IS A DIFF CLASS SO WE ARE CONVERTING THIS INTO A list
        print(i)
os.chdir('‪dir')

y=[]
resolution_list=[]
for i in images:
    x=plt.imread(i)  #READING IMAGE
    l,w,rgb=np.shape(x)  #USING NUMPY, STORING THE VALUES OF ATTRIBUTES OF IMAGE
    y.append(l*w)  #COLLECTING THE SIZE OF IMAGES INTO A LIST
    resolution_list.append((i,l,w,l*w))
Quicksort(y, 0, len(y) - 1)  #SORTING IMAGE
search_list=resolution_list.copy()
for i in y:
    length=len(resolution_list)
    for j in range(length):
        if resolution_list[j][3]==i:
            m=plt.imread(resolution_list[j][0])
            plt.imshow(m)
            plt.show()
            resolution_list.remove(resolution_list[j])#
            break

#           ******SEARCHING FOR AN IMAGE GIVEN BY USER AS INPUT***********
im=input("Enter an image file:")
try:
    r=plt.imread(im)
    l1,w1,rgb1=np.shape(r)
    for i in range(len(search_list)):
        if search_list[i][1]==l1 and search_list[i][2]==w1 :
            constant=0
            t=plt.imread(search_list[i][0])
            le,wi,rgb2=np.shape(t)
            if rgb2==rgb1 and rgb2==3:#CHECKING IF THE CHANNELS ARE EQUAL IN COLOUR IMAGES
                for j in range(l1):
                    for k in range(w1):
                        for p in range(3):
                            if t[j][k][p]==r[j][k][p]:#CHECKING IF EACH PIXEL VALUE IS EQUAL
                                continue
                            else:
                                constant=1
                                break
            elif rgb2==rgb1 and rgb2!=3:#FOR GREY IMAGES
                for j in range(l1):
                    for k in range(w1):
                        if t[j][k]==r[j][k]:#CHECKING GREY VALUES
                            continue
                        else:
                            constant=1
                            break
            else:
                print("Image not found in the list")
                break

            if constant!=1:
                print("Image found")
                plt.imshow(t)
                plt.show()
                break
        elif i==len(search_list)-1:
            print("Image not found in the list")

        else:
            continue

except FileNotFoundError as e:
    print("File not found in the list")
